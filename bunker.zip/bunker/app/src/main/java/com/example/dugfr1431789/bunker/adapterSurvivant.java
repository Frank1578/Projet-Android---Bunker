package com.example.dugfr1431789.bunker;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by DugFr1431789 on 2018-05-06.
 */

public class adapterSurvivant extends ArrayAdapter<UnSurvivant> {
    private Activity activity;
    private ArrayList<UnSurvivant> lSurvivant;
    private static LayoutInflater inflater = null;

    public adapterSurvivant(Activity activity, int textViewRessourceId, ArrayList<UnSurvivant> _lSurvivant){
        super(activity, textViewRessourceId, _lSurvivant);
        try{
            this.activity = activity;
            this.lSurvivant = _lSurvivant;

            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }catch (Exception e){

        }
    }

    public int getCount(){
        return lSurvivant.size();
    }

//    public UnSurvivant getItem(UnSurvivant position){
//        return position;
//    }

    public long getItemId(int position){
        return position;
    }

    public static class ViewHolder{
        public TextView nom;
        public TextView metier;
        public TextView force;
        public TextView intel;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        View vi = convertView;
        final ViewHolder holder;
        try{
            if(convertView == null){
                vi = inflater.inflate(R.layout.survivants, null);
                holder = new ViewHolder();

                holder.nom = (TextView) vi.findViewById(R.id.nomSurv);
                holder.metier = (TextView) vi.findViewById(R.id.metierSurv);
                holder.force = (TextView) vi.findViewById(R.id.forceSurv);
                holder.intel = (TextView) vi.findViewById(R.id.intelSurv);

                vi.setTag(holder);
            }else{
                holder = (ViewHolder) vi.getTag();
            }

            holder.nom.setText(lSurvivant.get(position).nomS);
            holder.metier.setText(lSurvivant.get(position).metierS);
            holder.force.setText(lSurvivant.get(position).forceS);
            holder.intel.setText(lSurvivant.get(position).intelS);
        }catch (Exception e){

        }
        return vi;
    }
}
