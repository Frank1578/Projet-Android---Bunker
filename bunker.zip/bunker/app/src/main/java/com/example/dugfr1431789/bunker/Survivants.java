package com.example.dugfr1431789.bunker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by DugFr1431789 on 2018-05-06.
 */

public class Survivants extends Activity{
    ArrayAdapter<String> adapter;
    ArrayList<String> listSurvivorString = new ArrayList<String>();
//    adapterSurvivant adbSurvivant;
    ArrayList<UnSurvivant> listItemSurvivant = new ArrayList<UnSurvivant>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.survivants);
        ListView listSurv = (ListView) findViewById(R.id.lstSurvivant);

        survivantGenerer(listSurv);



//
//
//        adapter = new ArrayAdapter<String>(Survivants.this,
//                android.R.layout.simple_list_item_1, listSurvivorString);
//        listSurv.setAdapter(adapter);
    }

    public void survivantGenerer(ListView list){
        Random rnd = new Random();
        int randomPren = rnd.nextInt(25);
        int randomMetier = rnd.nextInt(4);
        int randomForce = rnd.nextInt(10);
        int randomIntel = rnd.nextInt(10);

        String[] prenoms = new String[]{
                "Antoine", "Benoit", "Cyril", "David", "Eloise", "Florent",
                "Gerard", "Hugo", "Ingrid", "Jonathan", "Kevin", "Logan",
                "Mathieu", "Noemie", "Olivia", "Philippe", "Quentin", "Romain",
                "Sophie", "Tristan", "Ulric", "Vincent", "Willy", "Xavier",
                "Yann", "Zoé"
        };
        String[] metier = new String[]{
                "Test1", "Test2", "Test3", "Test4", "Test5"
        };

        UnSurvivant[] survivor = {
                new UnSurvivant(prenoms[randomPren], metier[randomMetier], String.valueOf(randomForce), String.valueOf(randomIntel))
        };

        ArrayAdapter<UnSurvivant> adapter = new ArrayAdapter<UnSurvivant>(this, android.R.layout.simple_list_item_1, survivor);

        list.setAdapter(adapter);
    }

    public List<UnSurvivant> genererUnSurvivant(){
        Random rnd = new Random();
        int randomPren = rnd.nextInt(25);
        int randomMetier = rnd.nextInt(4);
        int randomForce = rnd.nextInt(10);
        int randomIntel = rnd.nextInt(10);

        String[] prenoms = new String[]{
                "Antoine", "Benoit", "Cyril", "David", "Eloise", "Florent",
                "Gerard", "Hugo", "Ingrid", "Jonathan", "Kevin", "Logan",
                "Mathieu", "Noemie", "Olivia", "Philippe", "Quentin", "Romain",
                "Sophie", "Tristan", "Ulric", "Vincent", "Willy", "Xavier",
                "Yann", "Zoé"
        };
        String[] metier = new String[]{
                "Test1", "Test2", "Test3", "Test4", "Test5"
        };

        listItemSurvivant.add(new UnSurvivant(prenoms[randomPren], metier[randomMetier], String.valueOf(randomForce), String.valueOf(randomIntel)));
        return listItemSurvivant;
    }

    public void genererSurv(View v){
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.menusurvivants, popup.getMenu());
        popup.show();
    }

    public boolean onMenuItemClick(MenuItem item){
        switch (item.getItemId()){
            case R.id.Activites:
                Intent intent1 = new Intent(this, activites.class);
                startActivity(intent1);
//                startActivityForResult(intent1, REQUEST_CODE);
//                intent1.putExtra("EauRes", String.valueOf(getEau));
//                intent1.putExtra("ElectRes", String.valueOf(getElect));
//                intent1.putExtra("NourrRes", String.valueOf(getNourr));
//                setResult(Activity.RESULT_OK,intent1);
//                finish();
                return  true;
            case R.id.Accueil:
                Intent intent2 = new Intent(this, MainActivity.class);
                startActivity(intent2);
                return  true;
            case R.id.Regles:
                Intent intent3 = new Intent(this, Regles.class);
                startActivity(intent3);
                return true;
            case R.id.Ressources:
                Intent intent4 = new Intent(this, Ressources.class);
                startActivity(intent4);
                return true;
            default:
                return false;
        }
    }
}
